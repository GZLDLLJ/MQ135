/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2022/08/08
 * Description        : Main program body.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for 
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/

/*
 *@Note
 Multiprocessor communication mode routine:
 Master:USART1_Tx(PD5)\USART1_Rx(PD6).
 This routine demonstrates that USART1 receives the data sent by CH341 and inverts
 it and sends it (baud rate 115200).

 Hardware connection:PD5 -- Rx
                     PD6 -- Tx

*/

#include "debug.h"
#include "TM1652.h"
#include "MQ135.h"
/* Global define */


/* Global Variable */



/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
int main(void)
{

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Delay_Init();
    USART_Printf_Init(115200);
    printf("SystemClk:%d\r\n",SystemCoreClock);

    TM1652_GPIO_Init();
    MQ135_Init();
    Delay_Ms(1000);

    while(1)
    {

        printf("\r\nad_value:%4.2fV\r\n",ADC_ConvertedValue*3.3/1024);
        TM_Digtal_Display(ADC_ConvertedValue);
        if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2))
        {
            printf("Gas leakage!!!\n");
        }else{

            printf("Gas not leakage!!!\n");
        }
        Delay_Ms(500);

    }
}
