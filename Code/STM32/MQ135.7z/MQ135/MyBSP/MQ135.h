/*
 * LightDio.h
 *
 *  Created on: Apr 22, 2023
 *      Author: Administrator
 */

#ifndef MYBSP_MQ135_H_
#define MYBSP_MQ135_H_
#include "debug.h"

extern u16 ADC_ConvertedValue;
extern void MQ135_Init(void);



#endif /* MYBSP_LIGHTDIO_H_ */
