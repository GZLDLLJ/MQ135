/*
 * TM1652.h
 *
 *  Created on: Apr 18, 2023
 *      Author: Administrator
 */

#ifndef MYBSP_TM1652_H_
#define MYBSP_TM1652_H_
#include "debug.h"
#define  DIN(x) (x?GPIO_SetBits(GPIOD,GPIO_Pin_0):GPIO_ResetBits(GPIOD,GPIO_Pin_0))
extern void TM1652_GPIO_Init(void);

extern void TM_Digtal_Display(u16 num);
#endif /* MYBSP_TM1652_H_ */
