/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2021/06/06
 * Description        : Main program body.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for 
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/

/*
 *@Note
 USART Print debugging routine:
 USART1_Tx(PA9).
 This example demonstrates using USART1(PA9) as a print debug port output.

*/

#include "debug.h"
#include "TM1652.h"
#include "MQ135.h"
/* Global typedef */

/* Global define */

/* Global Variable */

/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
int main(void)
{
    u16 adval=0;
    u16 tick=0;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Delay_Init();
    USART_Printf_Init(115200);
    printf("SystemClk:%d\r\n", SystemCoreClock);

    printf("This is printf example\r\n");
    TM1652_GPIO_Init();
    Delay_Ms(10);
    ADC_DMA_CONF();
    while(1)
    {
        TM_Digtal_Display(tick);
        Delay_Ms(950);
        if(++tick>180)
        {
            tick=0;
           break;
        }
    }
    while(1)
    {
        adval=getMQ135_AdValue();
        TM_Digtal_Display(adval);
        Delay_Ms(300);
    }
}
