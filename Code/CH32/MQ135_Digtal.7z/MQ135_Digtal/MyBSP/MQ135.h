#ifndef __MQ135_H
#define __MQ135_H

#include "debug.h"

void adc_Init(void);

void DMA_Tx_Init(void);

void ADC_DMA_CONF(void);
u16 getMQ135_AdValue(void);
 
#endif 
